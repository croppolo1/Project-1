import arcade
import os
import pathlib
import random

screen_w = 640
screen_h =640
gameTitle = "Side Scroller"

shotSpeed = 10


class sideScroller(arcade.Window):

    def __init__(self, screenWidth, screenHeight, title):
        super().__init__(screenWidth, screenHeight, title)

        self.character_list = None
        self.character = None
        self.game_background = None
        self.list_of_background = None
        self.list_of_bullets = None
        self.gunSound = arcade.sound.load_sound(pathlib.Path.cwd() / 'Assets' / 'gunshot.wav')

    def game_setup(self):

        self.game_background = arcade.Sprite(pathlib.Path.cwd() / 'Assets' / 'spacebg.png')
        self.game_background.center_y = 320
        self.game_background.center_x = 320
        self.game_background.change_x -= 4

        self.other_background = arcade.Sprite(pathlib.Path.cwd() / 'Assets' / 'spacebg.png')
        self.other_background.center_y = 320
        self.other_background.center_x = 960
        self.other_background.change_x -= 4

        self.character_list = arcade.SpriteList()
        self.list_of_bullets = arcade.SpriteList()
        self.list_of_background = arcade.SpriteList()
        self.list_of_background.append(self.game_background)
        self.list_of_background.append(self.other_background)

        self.character = arcade.Sprite(pathlib.Path.cwd() / 'Assets' / 'PlayerShip.png')
        self.character.center_y = 300
        self.character.center_x = 200
        self.character_list.append(self.character)

    def on_draw(self):
        arcade.start_render()
        self.list_of_bullets.draw()
        self.list_of_background.draw()
        self.character_list.draw()

    def on_key_press(self, key, modifiers):
        if key == arcade.key.UP:
            self.character.change_y = 5

        elif key == arcade.key.DOWN:
            self.character.change_y = -5

        elif key == arcade.key.LEFT:
            self.character.change_x = -5

        elif key == arcade.key.RIGHT:
            self.character.change_x = 5

        elif key == arcade.key.SPACE:
            shot = arcade.Sprite(pathlib.Path.cwd() / 'Assets' / 'bullet.png')
            shot.change_x += shotSpeed
            shot.center_y = self.character.center_y
            shot.center_x = self.character.center_x
            self.list_of_bullets.append(shot)
            arcade.play_sound(self.gunSound)

    def on_key_release(self, key, modifiers):
        if (key == arcade.key.UP):
            self.character.change_y = 0
        elif (key == arcade.key.DOWN):
            self.character.change_y = 0
        elif (key == arcade.key.LEFT):
            self.character.change_x = 0
        elif (key == arcade.key.RIGHT):
            self.character.change_x = 0
        else:
            pass

    def on_update(self, delta_time):

        self.character_list.update()
        self.list_of_bullets.update()
        plusWidth = 640
        if (self.game_background.left == -screen_w):
            self.game_background.center_x = screen_w + plusWidth // 2
        if (self.other_background.left == -screen_w):
            self.other_background.center_x = screen_w + plusWidth // 2
        self.list_of_background.update()

def main():
    window = sideScroller(screen_w, screen_h, gameTitle)
    window.game_setup()
    arcade.run()

if __name__ == '__main__':
    main()